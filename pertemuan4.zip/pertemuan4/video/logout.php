<?php
    session_start();
    //session_unset($_SESSION['nama_user]);
    session_destroy();

?>